package Project_WebApp.demo.controller;

import Project_WebApp.demo.SalesforceService;
import Project_WebApp.demo.dto.ValidationRuleToggleRequest;
import jakarta.servlet.http.HttpSession;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.ui.Model;

@Controller
public class DashboardController {

  @GetMapping("/dashboard")
  public String dashboard(HttpSession session) {

    if (session.getAttribute("ACCESS_TOKEN") == null) {
      return "redirect:/login";
    }

    return "Dashboard";
  }
}
