package Project_WebApp.demo;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class SalesforceService {

  /*
   * =========================
   * PUBLIC METHOD USED BY CONTROLLER
   * =========================
   */
  public Object getValidationRules(String accessToken, String instanceUrl) {
    return fetchMetadata(accessToken, instanceUrl);
  }

  /*
   * =========================
   * FETCH VALIDATION RULES (Tooling API)
   * =========================
   */
  public Object fetchMetadata(String accessToken, String instanceUrl) {

    String url = instanceUrl
        + "/services/data/v59.0/tooling/query"
        + "?q=SELECT+Id,ValidationName,Active,EntityDefinition.QualifiedApiName"
        + "+FROM+ValidationRule";

    HttpHeaders headers = new HttpHeaders();
    headers.setBearerAuth(accessToken);
    headers.setContentType(MediaType.APPLICATION_JSON);

    HttpEntity<Void> entity = new HttpEntity<>(headers);

    RestTemplate restTemplate = new RestTemplate();

    ResponseEntity<Object> response = restTemplate.exchange(url, HttpMethod.GET, entity, Object.class);

    return response.getBody();
  }

  /*
   * =========================
   * TOGGLE VALIDATION RULE
   * =========================
   */
  public void toggleValidationRule(
      String ruleId,
      boolean active,
      String accessToken,
      String instanceUrl) {

    // 🔴 DO NOTHING FOR NOW
    // This restores last-night behavior

    System.out.println(
        "Toggle clicked (UI-only): ruleId=" + ruleId + ", active=" + active);
  }
}
